//여기에다가 코딩하세요

//EXAMPLES
// import { events } from "messangerbot/events";

// events.receiveMessage.on((msg)=> {
//     console.log(msg.author.name);
// })