"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.jsoup = void 0;
//@ts-expect-error
importClass(org.jsoup.Jsoup);
var jsoup;
(function (jsoup) {
    function connect(url) {
        //@ts-expect-error
        return Jsoup.connect(url);
    }
    jsoup.connect = connect;
})(jsoup || (exports.jsoup = jsoup = {}));
var JsoupConnection = /** @class */ (function () {
    function JsoupConnection() {
    }
    /**
     * @virtual Sorry, I'm too lazy to make other classes and virtual methods T.T
     */
    JsoupConnection.prototype.get = function () { };
    ;
    return JsoupConnection;
}());
// class HTMLData {
//     /**
//      * @virtual
//      */
//     public select(string: string): HTMLData {
//         return new HTMLData();
//     };
//     /**
//      * @virtual
//      */
//     public get(index: string): HTMLData {
//         return new HTMLData();
//     };
//     /**
//      * @virtual
//      */
//     public attr(string: string): any[] {
//         return [];
//     };
//     /**
//      * @virtual
//      */
//     public text(): string {
//         return "";
//     };
//     /**
//      * @virtual
//      */
//     public size(): number {
//         return -1;
//     };
// }
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiSnNvdXAuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJKc291cC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxrQkFBa0I7QUFDbEIsV0FBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7QUFFN0IsSUFBaUIsS0FBSyxDQUtyQjtBQUxELFdBQWlCLEtBQUs7SUFDbEIsU0FBZ0IsT0FBTyxDQUFDLEdBQVc7UUFDL0Isa0JBQWtCO1FBQ2xCLE9BQU8sS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUM5QixDQUFDO0lBSGUsYUFBTyxVQUd0QixDQUFBO0FBQ0wsQ0FBQyxFQUxnQixLQUFLLHFCQUFMLEtBQUssUUFLckI7QUFFRDtJQUFBO0lBS0EsQ0FBQztJQUpHOztPQUVHO0lBQ0ksNkJBQUcsR0FBVixjQUFtQixDQUFDO0lBQUEsQ0FBQztJQUN6QixzQkFBQztBQUFELENBQUMsQUFMRCxJQUtDO0FBRUQsbUJBQW1CO0FBQ25CLFVBQVU7QUFDVixrQkFBa0I7QUFDbEIsVUFBVTtBQUNWLGdEQUFnRDtBQUNoRCxpQ0FBaUM7QUFDakMsU0FBUztBQUVULFVBQVU7QUFDVixrQkFBa0I7QUFDbEIsVUFBVTtBQUNWLDRDQUE0QztBQUM1QyxpQ0FBaUM7QUFDakMsU0FBUztBQUVULFVBQVU7QUFDVixrQkFBa0I7QUFDbEIsVUFBVTtBQUNWLDJDQUEyQztBQUMzQyxxQkFBcUI7QUFDckIsU0FBUztBQUVULFVBQVU7QUFDVixrQkFBa0I7QUFDbEIsVUFBVTtBQUNWLDhCQUE4QjtBQUM5QixxQkFBcUI7QUFDckIsU0FBUztBQUVULFVBQVU7QUFDVixrQkFBa0I7QUFDbEIsVUFBVTtBQUNWLDhCQUE4QjtBQUM5QixxQkFBcUI7QUFDckIsU0FBUztBQUNULElBQUkifQ==