const bot = BotManager.getCurrentBot();

const { events } = require("messangerbot/events");

function onMessage(msg) {
  events.receiveMessage.fire(msg);
}

function onCommand(msg) {
  events.receiveCommand.fire(msg);
}

function onCreate(savedInstanceState, activity) {
  events.create.fire(savedInstanceState, activity);
}

function onStart(activity) {
  events.start.fire(activity);
}

function onResume(activity) {
  events.resume.fire(activity);
}

function onPause(activity) {
  events.pause.fire(activity);
}

function onStop(activity) {
  events.stop.fire(activity);
}

function onRestart(activity) {
  events.restart.fire(activity);
}

function onDestroy(activity) {
  events.destroy.fire(activity);
}

function onBackPressed(activity) {
  events.backPressed.fire(activity);
}

bot.addListener(Event.Activity.CREATE, onCreate);
bot.addListener(Event.Activity.START, onStart);
bot.addListener(Event.Activity.RESUME, onResume);
bot.addListener(Event.Activity.PAUSE, onPause);
bot.addListener(Event.Activity.STOP, onStop);
bot.addListener(Event.Activity.RESTART, onRestart);
bot.addListener(Event.Activity.DESTROY, onDestroy);
bot.addListener(Event.Activity.BACK_PRESSED, onBackPressed);
bot.addListener(Event.MESSAGE, onMessage);
bot.addListener(Event.COMMAND, onCommand);

bot.setCommandPrefix("/");

require("index");