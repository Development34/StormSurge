"use strict";
//여기에다가 코딩하세요
//EXAMPLES
// import { events } from "messangerbot/events";
// events.receiveMessage.on((msg)=> {
//     console.log(msg.author.name);
// })
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsYUFBYTtBQUViLFVBQVU7QUFDVixnREFBZ0Q7QUFFaEQscUNBQXFDO0FBQ3JDLG9DQUFvQztBQUNwQyxLQUFLIn0=