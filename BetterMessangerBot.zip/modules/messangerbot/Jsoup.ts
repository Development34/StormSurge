//@ts-expect-error
importClass(org.jsoup.Jsoup);

export namespace jsoup {
    export function connect(url: string): JsoupConnection {
        //@ts-expect-error
        return Jsoup.connect(url);
    }
}

class JsoupConnection {
    /**
     * @virtual Sorry, I'm too lazy to make other classes and virtual methods T.T
     */
    public get(): any {};
}

// class HTMLData {
//     /**
//      * @virtual
//      */
//     public select(string: string): HTMLData {
//         return new HTMLData();
//     };

//     /**
//      * @virtual
//      */
//     public get(index: string): HTMLData {
//         return new HTMLData();
//     };

//     /**
//      * @virtual
//      */
//     public attr(string: string): any[] {
//         return [];
//     };

//     /**
//      * @virtual
//      */
//     public text(): string {
//         return "";
//     };

//     /**
//      * @virtual
//      */
//     public size(): number {
//         return -1;
//     };
// }